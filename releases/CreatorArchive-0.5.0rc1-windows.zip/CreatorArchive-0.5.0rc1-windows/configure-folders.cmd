@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0configure-folders.ps1" %*
if errorlevel 1 pause
